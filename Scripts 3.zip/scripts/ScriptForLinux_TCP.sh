#!/bin/bash
DEFAULT_ROUTE=$(ip route show default | awk '/default/ {print $3}')
ping -c 5 $DEFAULT_ROUTE>ping.txt
ifconfig>ipconfig.txt
nmap -Pn --max-rtt-timeout 100ms --max-retries 3 --min-rate 450 --max-rate 15000 -oA ScanResults_10.2.2.80 10.2.2.80
nmap -Pn --max-rtt-timeout 100ms --max-retries 3 --min-rate 450 --max-rate 15000 -oA ScanResults_10.2.2.105 10.2.2.105
nmap -Pn --max-rtt-timeout 100ms --max-retries 3 --min-rate 450 --max-rate 15000 -oA ScanResults_10.2.2.196 10.2.2.196
nmap -Pn --max-rtt-timeout 100ms --max-retries 3 --min-rate 450 --max-rate 15000 -oA ScanResults_10.2.2.84 10.2.2.84
nmap -Pn --max-rtt-timeout 100ms --max-retries 3 --min-rate 450 --max-rate 15000 -oA ScanResults_10.2.2.116 10.2.2.116
nmap -Pn --max-rtt-timeout 100ms --max-retries 3 --min-rate 450 --max-rate 15000 -oA ScanResults_10.2.2.231 10.2.2.231
nmap -Pn --max-rtt-timeout 100ms --max-retries 3 --min-rate 450 --max-rate 15000 -oA ScanResults_10.2.2.243 10.2.2.243
nmap -Pn --max-rtt-timeout 100ms --max-retries 3 --min-rate 450 --max-rate 15000 -oA ScanResults_10.2.2.146 10.2.2.146
nmap -Pn --max-rtt-timeout 100ms --max-retries 3 --min-rate 450 --max-rate 15000 -oA ScanResults_10.2.3.143 10.2.3.143
printf "Scanning Completed\n"
